from .main import generate_data_matrix
from .nltkFunc import get_pos_tag